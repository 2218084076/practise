## STEP-1
1、安装Python版本，当前时间2021年11月，请下载Python3.9.x版本，鉴于TensorFlow暂无3.10.x版本pip。后期可能拥有。
2、PATH加入全局变量中，注意Windows和Mac操作系统区别，建议默认路径安装。
## STEP-2
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple opencv-python

opencv 自带数据集模型
https://github.com/opencv/opencv/tree/master/data/haarcascades

## STEP-3
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple dlib
高阶策略，使用dlib库，进行锚点获取